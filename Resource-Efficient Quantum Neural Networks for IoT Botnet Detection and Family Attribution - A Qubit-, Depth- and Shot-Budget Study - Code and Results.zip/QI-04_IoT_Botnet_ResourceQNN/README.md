# QI-04: Resource-efficient quantum neural networks for IoT botnet detection

**Suggested chapter title:** *Resource-Efficient Quantum Neural Networks for IoT Botnet Detection and Family Attribution: A Qubit-, Depth- and Shot-Budget Study*
**CFP topic:** 13 (Security hybrid defence architecture using quantum-based networks)

## Data
N-BaIoT (UCI #442): 9 commercial IoT devices and 115 Kitsune traffic statistics.
- Classes: benign, BASHLITE/gafgyt (5 attacks) and Mirai (5 attacks); 7,062,606 records in total.
- Two devices (Ennio doorbell, Samsung webcam) have no Mirai capture.
- `src/prepare_data.py` reads `data/n_baiot.zip` directly (RAR archives are extracted with `bsdtar`). It keeps a seeded random sample of up to 6,000 records per device × traffic file: **534,000 rows** in `data/nbaiot_sample.parquet`. Full per-file counts are in `nbaiot_counts.csv`.
- Features are signed-log transformed.
- Target: 3 classes (benign / gafgyt / mirai).

## Protocol
- Per seed: 1,500 train + 450 validation + 3,000 test records, class-balanced and disjoint.
- **E1:** compression to n_q ∈ {2, 4, 6, 8} using PCA, mutual-information top-k, or RF-importance top-k. Top-k selection drops features that correlate with an already-chosen one at |r| ≥ 0.95. Each compression feeds LogReg and a compact VQC (basic entangler, L = 2).
- **E2:** architecture/resource study at n_q = 6. Basic (1 parameter per qubit) vs strong (3 per qubit) ansatz, L ∈ {1, 2, 3, 4}. Records parameters, circuit depth, CNOT count and training time.
- **E3:** leave-one-device-out (train on 8 devices, test on the 9th), 3 seeds.
- **E4:** finite-shot inference, 32 to 4,096 shots per ⟨Z⟩.
- **E5:** depolarising noise at inference, p up to 0.05.

## Headline results (macro-F1, 5 seeds)
- **Feature selection beats PCA for small circuits.** At 6 qubits, the VQC scores 0.977 with RF-importance features and 0.972 with MI features, against 0.931 with PCA. LogReg on the same inputs scores 0.949 / 0.956 / 0.901 (`F03`, `T2`).
- **Basic-entangler VQC.** L = 2 with 33 parameters (depth 16, 12 CNOT) reaches 0.977. The strong ansatz with L = 4 (93 parameters, 24 CNOT) reaches 0.989. XGBoost on the same 6 features reaches 0.999 with about 3,700 tree nodes (`F04` Pareto, `T3`).
- **Deployment:**
  - Exact expectations: 0.977.
  - Finite shots: 0.967 at 512 shots and 0.834 at 32 (`F06a`).
  - Depolarising noise: F1 falls only from 0.978 to 0.969 at p = 0.05 (`F06b`).
- **Unseen devices (`F05`, `T4`):** the VQC generalises to 7 of 9 unseen devices (F1 0.95–0.98). On the two devices without Mirai traffic it falls to about 0.62–0.65, by predicting Mirai for traffic that is actually gafgyt or benign. LogReg shows the same failure; XGBoost does not. This is a clear, honest limitation of linear-readout compact models.

## Files
- `src/prepare_data.py`, `src/run_experiments.py` and `src/make_figures.py` produce 10 figures and 8 tables. `T7` lists the Kitsune features selected for each qubit budget.
- `references/` holds 5 papers:
  - Meidan 2018 (the N-BaIoT dataset paper).
  - Tehrani 2023 (quantum botnet analytics).
  - Bhowmik 2024.
  - Lloyd 2020 (quantum embeddings).
  - Chen 2025.

## Housekeeping
`data/` also holds the 1.8 GB `n_baiot.zip` and the per-device folders it unpacked to, about 2.6 GB in all. Only `nbaiot_sample.parquet` and `nbaiot_counts.csv` are needed to rerun the experiments. The zip is needed only to rebuild the sample. You can delete the per-device folders.
