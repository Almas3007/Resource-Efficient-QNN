**Raw Kitsune features chosen per qubit budget (seed 0)**

|   nq | method        | features                                                                                                                                             |
|-----:|:--------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------|
|    2 | MutualInfo    | H_L0.01_mean, HH_jit_L3_mean                                                                                                                         |
|    2 | RF-importance | HH_jit_L0.01_mean, MI_dir_L0.1_weight                                                                                                                |
|    4 | MutualInfo    | H_L0.01_mean, HH_jit_L3_mean, H_L0.1_weight, MI_dir_L0.01_variance                                                                                   |
|    4 | RF-importance | HH_jit_L0.01_mean, MI_dir_L0.1_weight, HH_jit_L0.1_mean, MI_dir_L0.01_mean                                                                           |
|    6 | MutualInfo    | H_L0.01_mean, HH_jit_L3_mean, H_L0.1_weight, MI_dir_L0.01_variance, HH_jit_L0.01_mean, MI_dir_L1_mean                                                |
|    6 | RF-importance | HH_jit_L0.01_mean, MI_dir_L0.1_weight, HH_jit_L0.1_mean, MI_dir_L0.01_mean, HpHp_L0.01_weight, HH_jit_L3_mean                                        |
|    8 | MutualInfo    | H_L0.01_mean, HH_jit_L3_mean, H_L0.1_weight, MI_dir_L0.01_variance, HH_jit_L0.01_mean, MI_dir_L1_mean, HH_L0.01_magnitude, HH_jit_L0.1_mean          |
|    8 | RF-importance | HH_jit_L0.01_mean, MI_dir_L0.1_weight, HH_jit_L0.1_mean, MI_dir_L0.01_mean, HpHp_L0.01_weight, HH_jit_L3_mean, HH_L0.01_weight, HH_jit_L0.1_variance |
