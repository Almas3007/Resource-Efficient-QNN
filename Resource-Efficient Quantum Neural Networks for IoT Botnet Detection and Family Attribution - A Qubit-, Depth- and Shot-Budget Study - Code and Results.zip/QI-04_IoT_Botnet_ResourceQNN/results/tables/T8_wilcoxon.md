**Wilcoxon over seeds (E2)**

| quantum        | reference   |   mean_diff | wins   |   wilcoxon_p |
|:---------------|:------------|------------:|:-------|-------------:|
| VQC-basic L=2  | LogReg      |      0.0284 | 5/5    |       0.0625 |
| VQC-basic L=2  | MLP         |     -0.0182 | 0/5    |       0.0625 |
| VQC-basic L=2  | XGBoost     |     -0.0212 | 0/5    |       0.0625 |
| VQC-strong L=2 | LogReg      |      0.0373 | 5/5    |       0.0625 |
| VQC-strong L=2 | MLP         |     -0.0093 | 0/5    |       0.0625 |
| VQC-strong L=2 | XGBoost     |     -0.0123 | 0/5    |       0.0625 |
| VQC-strong L=4 | LogReg      |      0.0404 | 5/5    |       0.0625 |
| VQC-strong L=4 | MLP         |     -0.0062 | 0/5    |       0.0625 |
| VQC-strong L=4 | XGBoost     |     -0.0092 | 0/5    |       0.0625 |
