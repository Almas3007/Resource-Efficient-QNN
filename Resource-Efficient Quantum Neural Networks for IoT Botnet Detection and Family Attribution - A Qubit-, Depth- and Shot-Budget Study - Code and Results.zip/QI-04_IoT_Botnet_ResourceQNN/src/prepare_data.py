"""Build a compact, reproducible sample of N-BaIoT (UCI #442) without keeping the ~7 GB of raw CSVs.

For each of the 9 devices: benign_traffic.csv plus every attack CSV inside gafgyt_attacks.rar and
mirai_attacks.rar (2 devices have no Mirai capture).  Up to PER_FILE rows are sampled uniformly at random
from every file (seed 0); labels: benign / gafgyt_<attack> / mirai_<attack>.  Output: data/nbaiot_sample.parquet
and data/nbaiot_counts.csv with the full (unsampled) row count of every file.
"""
import os, subprocess, tempfile, zipfile, io
import numpy as np, pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ZIP = f"{ROOT}/data/n_baiot.zip"
PER_FILE = 6000
rng = np.random.default_rng(0)


def sample_csv(fileobj_or_path):
    df = pd.read_csv(fileobj_or_path)
    n = len(df)
    if n > PER_FILE:
        df = df.iloc[np.sort(rng.choice(n, PER_FILE, replace=False))]
    return df.astype("float32"), n


rows, counts = [], []
with zipfile.ZipFile(ZIP) as z:
    devices = sorted({p.split("/")[0] for p in z.namelist() if "/" in p and p.split("/")[0]})
    for dev in devices:
        with z.open(f"{dev}/benign_traffic.csv") as f:
            df, n = sample_csv(f)
        df["device"], df["label"] = dev, "benign"; rows.append(df); counts.append((dev, "benign", n))
        for fam in ("gafgyt", "mirai"):
            name = f"{dev}/{fam}_attacks.rar"
            if name not in z.namelist():
                continue
            with tempfile.TemporaryDirectory() as td:
                rar = os.path.join(td, "a.rar")
                with open(rar, "wb") as out:
                    out.write(z.read(name))
                subprocess.run(["bsdtar", "-xf", rar, "-C", td], check=True)
                for csv in sorted(x for x in os.listdir(td) if x.endswith(".csv")):
                    df, n = sample_csv(os.path.join(td, csv))
                    lab = f"{fam}_{csv[:-4]}"
                    df["device"], df["label"] = dev, lab; rows.append(df); counts.append((dev, lab, n))
        print(dev, "done", flush=True)

data = pd.concat(rows, ignore_index=True)
data.to_parquet(f"{ROOT}/data/nbaiot_sample.parquet", index=False)
pd.DataFrame(counts, columns=["device", "label", "rows_full"]).to_csv(f"{ROOT}/data/nbaiot_counts.csv", index=False)
print(data.shape, data["label"].value_counts().to_dict())
