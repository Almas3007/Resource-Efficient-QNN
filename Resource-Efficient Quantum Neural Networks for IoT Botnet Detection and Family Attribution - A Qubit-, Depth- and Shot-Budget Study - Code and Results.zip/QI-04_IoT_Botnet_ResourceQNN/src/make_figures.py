"""QI-04 figures and tables."""
import os, sys, json, pickle
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "..", "common"))
import numpy as np, pandas as pd, torch
from report import (plt, savefig, agg, write_table, stats_table, pipeline_diagram, draw_circuit, confusion,
                    color_for, PALETTE)

FIG, TAB = f"{ROOT}/figures", f"{ROOT}/results/tables"
df = pd.read_csv(f"{ROOT}/results/all_runs.csv")
det = pickle.load(open(f"{ROOT}/results/seed0_details.pkl", "rb")); keep, ex = det["keep"], det["extras"]
info = json.load(open(f"{ROOT}/results/dataset_summary.json"))
counts = pd.read_csv(f"{ROOT}/data/nbaiot_counts.csv")
ms = lambda s: f"{s.mean():.4f} ± {s.std():.4f}"
short = lambda d: d.replace("_Security_Camera", " cam").replace("Provision_", "").replace("SimpleHome_", "").replace("_", " ")

# ---------------------------------------------------------------- tables
write_table(pd.DataFrame([dict(item=k, value=str(v)) for k, v in info.items()]), f"{TAB}/T1_dataset", "N-BaIoT")
e1 = df[df.exp == "E1"]
write_table(e1.groupby(["compression", "model", "nq"]).f1.apply(ms).unstack().reset_index(), f"{TAB}/T2_E1_compression",
            "E1: macro-F1 (3-class) vs qubits and compression method")
t, _ = agg(df[df.exp == "E2"], "model"); write_table(t.sort_values("n_params"), f"{TAB}/T3_E2_architecture",
                                                       "E2: architecture/resource study (n_q = 6, RF-importance features)")
e3 = df[df.exp == "E3"]
write_table(e3.groupby(["heldout", "model"]).f1.apply(ms).unstack().reset_index(), f"{TAB}/T4_E3_leave_one_device_out",
            "E3: leave-one-device-out macro-F1 (3 seeds)")
write_table(df[df.exp == "E4"].groupby("shots").f1.apply(ms).reset_index(), f"{TAB}/T5_E4_shots", "E4: finite-shot inference (0 = exact)")
write_table(df[df.exp == "E5"].groupby("noise").f1.apply(ms).reset_index(), f"{TAB}/T6_E5_noise", "E5: depolarising noise at inference")
sel = pd.DataFrame([dict(nq=n, method=m, features=", ".join(f)) for (n, m), f in ex["selected"].items()])
write_table(sel, f"{TAB}/T7_selected_features", "Raw Kitsune features chosen per qubit budget (seed 0)")
write_table(stats_table(df[df.exp == "E2"], "model", "f1", ["VQC-basic L=2", "VQC-strong L=2", "VQC-strong L=4"],
                        ["LogReg", "MLP", "XGBoost"]).round(4), f"{TAB}/T8_wilcoxon", "Wilcoxon over seeds (E2)")

# ---------------------------------------------------------------- F1 pipeline + F2 circuits
pipeline_diagram([
    ("IoT traffic", "N-BaIoT, 9 devices\nMirai + BASHLITE\n115 Kitsune stats\n7.06 M records"),
    ("Feature budget", "signed-log\nPCA / mutual info /\nRF importance\n→ 2–8 features"),
    ("Compact QNN", "RY re-uploading\nbasic (1 param/qubit)\nor strong (3)\nL = 1–4"),
    ("Resources", "parameters, depth,\nCNOT count,\nshots per\nexpectation"),
    ("Deployment tests", "leave-one-device-out\nfinite shots\ndepolarising noise"),
    ("Output", "benign / gafgyt /\nmirai attribution\nmacro-F1, Pareto\nfront")],
    f"{FIG}/F01_pipeline", quantum_idx=(2, 3))
from qsec import VQC
for ans in ("basic", "strong"):
    m = VQC(6, 2, 3, reupload=True, ansatz=ans)
    draw_circuit(m.circ, (torch.rand(6) * np.pi, m.w.detach()), f"{FIG}/F02_{ans}_circuit")

# ---------------------------------------------------------------- F3 compression x qubits
fig, ax = plt.subplots(figsize=(5.6, 3.6))
cols = {"PCA": PALETTE["grey"], "MutualInfo": PALETTE["classical"], "RF-importance": PALETTE["quantum"]}
for (comp, model), g in e1.groupby(["compression", "model"]):
    s = g.groupby("nq").f1
    ax.errorbar(s.mean().index, s.mean(), s.std(), color=cols[comp], ls="-" if "VQC" in model else "--",
                marker="o" if "VQC" in model else "s", ms=3.5, capsize=2, label=f"{model} · {comp}")
ax.set_xlabel("qubits = retained features"); ax.set_ylabel("macro-F1 (3-class)"); ax.set_xticks([2, 4, 6, 8])
ax.legend(fontsize=6.3, ncol=2); savefig(fig, f"{FIG}/F03_compression_vs_qubits")

# ---------------------------------------------------------------- F4 Pareto
e2 = df[df.exp == "E2"].groupby("model")[["f1", "n_params", "circuit_depth", "n_2q"]].mean()
fig, ax = plt.subplots(figsize=(5.6, 3.8))
for name, r in e2.iterrows():
    ax.scatter(r.n_params, r.f1, color=color_for(name), s=34, marker="o" if "VQC" in name else "s")
    lab = name + (f"\n(depth {int(r.circuit_depth)}, {int(r.n_2q)} CNOT)" if "VQC" in name and not np.isnan(r.circuit_depth) else "")
    ax.annotate(lab, (r.n_params, r.f1), fontsize=5.6, xytext=(3, -8 if "strong" in name else 3), textcoords="offset points")
ax.set_xscale("log"); ax.set_xlabel("trainable parameters / tree nodes (log)"); ax.set_ylabel("macro-F1")
savefig(fig, f"{FIG}/F04_pareto_resources")

# ---------------------------------------------------------------- F5 leave-one-device-out
pv = e3.groupby(["heldout", "model"]).f1.mean().unstack()
fig, ax = plt.subplots(figsize=(8, 3.6)); x = np.arange(len(pv)); w = 0.2
for i, m in enumerate(pv.columns):
    ax.bar(x + (i - 1.5) * w, pv[m], w, label=m, color=color_for(m) if "115" not in m else PALETTE["classical2"])
ax.set_xticks(x); ax.set_xticklabels([short(d) for d in pv.index], rotation=25, ha="right", fontsize=7)
ax.set_ylabel("macro-F1 on unseen device"); ax.set_ylim(0.4, 1.02); ax.legend(fontsize=7, ncol=4)
savefig(fig, f"{FIG}/F05_leave_one_device_out")

# ---------------------------------------------------------------- F6 shots / F7 noise
fig, axes = plt.subplots(1, 2, figsize=(9, 3.2))
g = df[(df.exp == "E4") & (df.shots > 0)].groupby("shots").f1
ex_f1 = df[(df.exp == "E4") & (df.shots == 0)].f1.mean()
axes[0].errorbar(g.mean().index, g.mean(), g.std(), marker="o", color=PALETTE["quantum"], capsize=2)
axes[0].axhline(ex_f1, ls=":", color="#888", label="exact expectation"); axes[0].set_xscale("log", base=2)
axes[0].set_xlabel("shots per ⟨Z⟩ estimate"); axes[0].set_ylabel("macro-F1"); axes[0].legend(fontsize=7)
axes[0].set_title("(a) finite-shot inference", loc="left")
g = df[df.exp == "E5"].groupby("noise").f1
axes[1].errorbar(g.mean().index, g.mean(), g.std(), marker="o", color=PALETTE["quantum"], capsize=2)
axes[1].set_xlabel("depolarising probability per qubit per layer"); axes[1].set_ylabel("macro-F1")
axes[1].set_title("(b) hardware noise at inference", loc="left")
fig.tight_layout(); savefig(fig, f"{FIG}/F06_shots_and_noise")

# ---------------------------------------------------------------- F8 confusion
key = lambda m: (("compression", "RF-importance"), ("exp", "E2"), ("nq", 6), m)
fig, axes = plt.subplots(1, 3, figsize=(10, 3.2))
for ax, m in zip(axes, ["LogReg", "VQC-basic L=2", "XGBoost"]):
    confusion(ax, ex["yte"], keep[key(m)]["pred"], ["benign", "gafgyt", "mirai"], m)
fig.tight_layout(); savefig(fig, f"{FIG}/F07_confusion")

# ---------------------------------------------------------------- F9 training curves
fig, ax = plt.subplots(figsize=(5, 3.3))
for m in ["VQC-basic L=1", "VQC-basic L=2", "VQC-basic L=4", "VQC-strong L=2", "VQC-strong L=4"]:
    h = pd.DataFrame(keep[key(m)]["history"]); ax.plot(h.epoch, h.val_f1, label=m)
ax.set_xlabel("epoch"); ax.set_ylabel("validation macro-F1"); ax.legend(fontsize=7)
savefig(fig, f"{FIG}/F08_training_curves")

# ---------------------------------------------------------------- F10 dataset composition
c = counts.assign(fam=counts.label.str.split("_").str[0]).pivot_table(index="device", columns="fam", values="rows_full", aggfunc="sum").fillna(0)
fig, ax = plt.subplots(figsize=(7, 3.4)); bottom = np.zeros(len(c))
for fam, col in zip(["benign", "gafgyt", "mirai"], [PALETTE["classical"], PALETTE["tree"], PALETTE["quantum"]]):
    ax.bar(range(len(c)), c[fam] / 1e3, bottom=bottom, color=col, label=fam); bottom += c[fam] / 1e3
ax.set_xticks(range(len(c))); ax.set_xticklabels([short(d) for d in c.index], rotation=25, ha="right", fontsize=7)
ax.set_ylabel("records (thousands)"); ax.legend(); savefig(fig, f"{FIG}/F09_dataset_composition")
print("figures:", len([f for f in os.listdir(FIG) if f.endswith(".png")]), "tables:", len(os.listdir(TAB)) // 2)
