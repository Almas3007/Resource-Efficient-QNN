"""QI-04  Resource-efficient quantum neural networks for IoT botnet detection (N-BaIoT).

Dataset : N-BaIoT (UCI #442; 9 commercial IoT devices, 115 Kitsune traffic statistics, benign + 10 Mirai /
          BASHLITE(gafgyt) attacks, 7,062,606 records).  prepare_data.py keeps a reproducible random sample of
          up to 6,000 records per device x traffic file (data/nbaiot_sample.parquet).
Target  : 3-class {benign, gafgyt, mirai} (botnet-family attribution; benign vs botnet reported too).
Design  : per seed 1,500 train + 450 validation (class-balanced), 3,000 balanced test records, disjoint.
Experiments
  E1 feature compression to n_q in {2,4,6,8}: PCA vs mutual-information top-k vs random-forest top-k raw
     features, each feeding LogReg and a compact VQC (basic entangler, L = 2, re-uploading)
  E2 architecture/resource Pareto study at the best compression: ansatz {basic, strong} x L {1,2,3,4}
     -> macro-F1 vs trainable parameters, circuit depth, 2-qubit gates, training time
  E3 leave-one-device-out generalisation (train on 8 devices, test on the unseen 9th)
  E4 finite-shot inference (32 ... 4,096 shots per expectation value, and exact)
  E5 depolarising-noise robustness at inference (p in {0, .005, .01, .02, .05})
Usage   : python3 src/run_experiments.py [--seeds 5] [--workers 5] [--quick]
"""
import os, sys, argparse, pickle, time
from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "..", "common"))
os.environ.setdefault("QSEC_THREADS", "1")
import xgboost  # noqa: F401  (import before torch: macOS libomp clash)
import numpy as np, pandas as pd, torch
from sklearn.feature_selection import mutual_info_classif
from sklearn.ensemble import RandomForestClassifier
from qsec import Reducer, stratified_sample, save_json, metrics, VQC, predict_proba_torch
from bench import classical_models, run_classical, run_vqc

OUT = f"{ROOT}/results"
N_TRAIN, N_VAL, N_TEST = 1500, 450, 3000
FAM = {"benign": 0, "gafgyt": 1, "mirai": 2}
FAM_NAMES = ["benign", "gafgyt", "mirai"]


def load():
    df = pd.read_parquet(f"{ROOT}/data/nbaiot_sample.parquet")
    df["fam"] = df["label"].str.split("_").str[0].map(FAM)
    feats = [c for c in df.columns if c not in ("device", "label", "fam")]
    X = df[feats].to_numpy(np.float64)
    X = np.sign(X) * np.log1p(np.abs(X))          # heavy-tailed traffic statistics -> signed log
    counts = pd.read_csv(f"{ROOT}/data/nbaiot_counts.csv")
    info = dict(sample_rows=len(df), n_features=len(feats), devices=sorted(df.device.unique()),
                sample_by_family=df.fam.map(dict(enumerate(FAM_NAMES))).value_counts().to_dict(),
                full_rows=int(counts.rows_full.sum()),
                full_by_family=counts.assign(f=counts.label.str.split("_").str[0]).groupby("f").rows_full.sum().to_dict())
    return X, df["fam"].to_numpy(), df["device"].to_numpy(), feats, info


def selectors(X, y, n, seed):
    mi = mutual_info_classif(X, y, random_state=seed)
    rf = RandomForestClassifier(200, n_jobs=1, random_state=seed).fit(X, y).feature_importances_

    def topk(score):  # greedy top-k with redundancy filter (|corr| < 0.95) so k features are not near-copies
        order, chosen = np.argsort(-score), []
        C = np.corrcoef(X.T)
        for j in order:
            if all(abs(C[j, i]) < 0.95 for i in chosen):
                chosen.append(j)
            if len(chosen) == n:
                break
        return np.array(chosen)
    return {"PCA": Reducer(n), "MutualInfo": Reducer(n, "select", topk(np.nan_to_num(mi))),
            "RF-importance": Reducer(n, "select", topk(rf))}


def strip(r):
    return {k: v for k, v in r.items() if not k.startswith("_") and k not in ("pred", "proba", "history")}


def one_seed(seed, quick=False):
    X, y, dev, feats, _ = load()
    s = stratified_sample(y, N_TRAIN + N_VAL, seed)
    tr, va = s[:N_TRAIN], s[N_TRAIN:]
    rest = np.setdiff1d(np.arange(len(y)), s)
    te = stratified_sample(y, N_TEST if not quick else 900, 1000 + seed, rest)
    ep = 5 if quick else 20
    rows, keep = [], {}

    def log(r, **tags):
        row = strip(r); row.update(tags, seed=seed); rows.append(row)
        if seed == 0:
            keep[tuple(sorted(tags.items())) + (r["model"],)] = dict(pred=r.get("pred"), proba=r.get("proba"),
                                                                    history=r.get("history"))
        print(f"[seed {seed}] {tags} {r['model']:<20} F1={r['f1']:.4f} params={r.get('n_params')} "
              f"t={r.get('train_time', 0):.1f}s", flush=True)

    # ---------------- E1 compression method x qubits
    sel_used = {}
    for n in ([2, 4] if quick else [2, 4, 6, 8]):
        for sname, red in selectors(X[tr], y[tr], n, seed).items():
            red.fit(X[tr])
            A, B, C = red.transform(X[tr]), red.transform(X[va]), red.transform(X[te])
            tg = dict(exp="E1", nq=n, compression=sname)
            log(run_classical("LogReg", classical_models(seed, 3)["LogReg"], A, y[tr], C, y[te]), **tg)
            log(run_vqc(A, y[tr], B, y[va], C, y[te], n, 2, True, seed, epochs=ep, ansatz="basic",
                        name="VQC-basic L=2"), **tg)
            if seed == 0 and sname != "PCA":
                sel_used[(n, sname)] = [feats[j] for j in red.feat_idx]

    # ---------------- E2 architecture Pareto (n_q = 6, best compression decided post-hoc -> run PCA and RF)
    NQ = 4 if quick else 6
    red = selectors(X[tr], y[tr], NQ, seed)["RF-importance"].fit(X[tr])
    A, B, C = red.transform(X[tr]), red.transform(X[va]), red.transform(X[te])
    best_model = None
    for ans in ("basic", "strong"):
        for L in ([1, 2] if quick else [1, 2, 3, 4]):
            r = run_vqc(A, y[tr], B, y[va], C, y[te], NQ, L, True, seed, epochs=ep, ansatz=ans,
                        name=f"VQC-{ans} L={L}")
            log(r, exp="E2", nq=NQ, compression="RF-importance")
            if ans == "basic" and L == 2:
                best_model = r["_model"]
    for name in ("LogReg", "MLP", "XGBoost"):
        log(run_classical(name, classical_models(seed, 3)[name], A, y[tr], C, y[te]), exp="E2", nq=NQ,
            compression="RF-importance")
    log(run_classical("XGBoost (115 feats)", classical_models(seed, 3)["XGBoost"], X[tr], y[tr], X[te], y[te]),
        exp="E2", nq=115, compression="none")

    # ---------------- E4 shots, E5 noise (on the compact basic L=2 model)
    rng = np.random.default_rng(seed)
    for shots in ([64, 1024, None] if quick else [32, 64, 128, 256, 512, 1024, 4096, None]):
        pr = best_model.forward_shots(C, shots, rng)
        log(dict(model="VQC-basic L=2", **metrics(y[te], pr.argmax(1), pr)), exp="E4", shots=shots or 0)
    for p in ([0.0, 0.02] if quick else [0.0, 0.005, 0.01, 0.02, 0.05]):
        noisy = VQC(NQ, 2, 3, reupload=True, noise=p, ansatz="basic")
        noisy.load_state_dict(best_model.state_dict())
        pr = predict_proba_torch(noisy, C[:1000])
        log(dict(model="VQC-basic L=2", **metrics(y[te][:1000], pr.argmax(1), pr)), exp="E5", noise=p)

    # ---------------- E3 leave-one-device-out (3 seeds only, n_q = 6, RF-importance)
    if seed < 3:
        devices = sorted(np.unique(dev))
        for d in (devices[:2] if quick else devices):
            in_d = np.where(dev != d)[0]; out_d = np.where(dev == d)[0]
            s2 = stratified_sample(y, N_TRAIN + N_VAL, seed, in_d)
            tr2, va2 = s2[:N_TRAIN], s2[N_TRAIN:]
            te2 = stratified_sample(y, 1500, seed, out_d)
            red2 = selectors(X[tr2], y[tr2], NQ, seed)["RF-importance"].fit(X[tr2])
            A2, B2, C2 = red2.transform(X[tr2]), red2.transform(X[va2]), red2.transform(X[te2])
            tg = dict(exp="E3", heldout=d, nq=NQ)
            log(run_vqc(A2, y[tr2], B2, y[va2], C2, y[te2], NQ, 2, True, seed, epochs=ep, ansatz="basic",
                        name="VQC-basic L=2"), **tg)
            for name in ("LogReg", "XGBoost"):
                log(run_classical(name, classical_models(seed, 3)[name], A2, y[tr2], C2, y[te2]), **tg)
            log(run_classical("XGBoost (115 feats)", classical_models(seed, 3)["XGBoost"], X[tr2], y[tr2],
                              X[te2], y[te2]), **tg)

    extras = dict(selected=sel_used, yte=y[te], e2_feats=[feats[j] for j in red.feat_idx]) if seed == 0 else {}
    return rows, keep, extras


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--workers", type=int, default=5)
    ap.add_argument("--quick", action="store_true")
    a = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    info = load()[-1]; save_json(info, f"{OUT}/dataset_summary.json"); print(info, flush=True)
    t0 = time.time()
    with ProcessPoolExecutor(a.workers, mp_context=mp.get_context("spawn")) as ex:
        outs = list(ex.map(one_seed, range(a.seeds), [a.quick] * a.seeds))
    pd.DataFrame([r for o in outs for r in o[0]]).to_csv(f"{OUT}/all_runs.csv", index=False)
    with open(f"{OUT}/seed0_details.pkl", "wb") as f:
        pickle.dump(dict(keep=outs[0][1], extras=outs[0][2]), f)
    print(f"done in {(time.time() - t0) / 60:.1f} min", flush=True)


if __name__ == "__main__":
    main()
