"""bench: uniform model zoo (classical + quantum) evaluated on identical reduced features and partitions."""
import time
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from qsec import (VQC, train_torch, predict_proba_torch, encode_states, fidelity_kernel, reduced_1q,
                  projected_kernel, metrics, f1_score, set_seed)


def _softmax(z):
    z = z - z.max(1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(1, keepdims=True)


def _scores_to_proba(dec, k):
    if dec.ndim == 1:
        p = 1 / (1 + np.exp(-dec))
        return np.c_[1 - p, p]
    return _softmax(dec)


def classical_models(seed, n_classes):
    return {
        "LogReg": LogisticRegression(max_iter=2000, C=1.0),
        "RBF-SVM": SVC(C=1.0, gamma="scale", random_state=seed),
        "MLP": MLPClassifier(hidden_layer_sizes=(16,), max_iter=1000, random_state=seed),
        "RandomForest": RandomForestClassifier(n_estimators=200, n_jobs=2, random_state=seed),
        "XGBoost": XGBClassifier(n_estimators=200, max_depth=6, learning_rate=0.1, n_jobs=2, random_state=seed,
                                 objective="binary:logistic" if n_classes == 2 else "multi:softprob",
                                 eval_metric="logloss"),
    }


def n_params_sklearn(m):
    if hasattr(m, "coef_"):
        return int(m.coef_.size + m.intercept_.size)
    if hasattr(m, "coefs_"):
        return int(sum(w.size for w in m.coefs_) + sum(b.size for b in m.intercepts_))
    if hasattr(m, "support_vectors_"):
        return int(m.support_vectors_.size + m.dual_coef_.size)
    if hasattr(m, "estimators_"):
        return int(sum(e.tree_.node_count for e in m.estimators_))
    if hasattr(m, "get_booster"):
        return int(sum(t.count("\n") for t in m.get_booster().get_dump()))
    return -1


def run_classical(name, model, Xtr, ytr, Xte, yte, **mkw):
    t0 = time.time(); model.fit(Xtr, ytr); tt = time.time() - t0
    t0 = time.time()
    if hasattr(model, "predict_proba") and not isinstance(model, SVC):
        proba = model.predict_proba(Xte)
    else:
        proba = _scores_to_proba(model.decision_function(Xte), len(np.unique(ytr)))
    pred = proba.argmax(1); it = time.time() - t0
    return dict(model=name, family="classical", pred=pred, proba=proba, train_time=tt, infer_time=it,
                n_params=n_params_sklearn(model), **metrics(yte, pred, proba, **mkw))


def run_vqc(Xtr, ytr, Xva, yva, Xte, yte, nq, layers, reupload, seed, epochs=25, lr=0.05, bs=64,
            class_weight=None, focal_gamma=0.0, noise=0.0, name=None, ansatz="strong", **mkw):
    set_seed(seed)
    k = len(np.unique(ytr))
    m = VQC(nq, layers, k, reupload=reupload, noise=noise, ansatz=ansatz)
    info = train_torch(m, Xtr, ytr, Xva, yva, epochs=epochs, lr=lr, bs=bs, seed=seed,
                       class_weight=class_weight, focal_gamma=focal_gamma)
    t0 = time.time(); proba = predict_proba_torch(m, Xte); it = time.time() - t0
    pred = proba.argmax(1)
    res = m.resources()
    name = name or f"VQC(L={layers}{',RU' if reupload else ''})"
    return dict(model=name, family="quantum", pred=pred, proba=proba, train_time=info["train_time"],
                infer_time=it, n_params=m.n_params(), history=info["history"], circuit_depth=res["depth"],
                n_gates=res["gates"], n_2q=res["two_qubit"], _model=m, **metrics(yte, pred, proba, **mkw))


def run_qsvm(Xtr, ytr, Xva, yva, Xte, yte, nq, fmap="zz", reps=2, bw=1.0, kind="fidelity", gamma=None,
             Cs=(0.1, 1.0, 10.0), seed=0, name=None, return_kernel=False, **mkw):
    """Quantum-kernel SVM; C chosen on the validation split, then refitted on train."""
    t0 = time.time()
    Str, Sva, Ste = (encode_states(X, nq, fmap, reps, bw) for X in (Xtr, Xva, Xte))
    if kind == "fidelity":
        Ktr, Kva, Kte = fidelity_kernel(Str, Str), fidelity_kernel(Sva, Str), fidelity_kernel(Ste, Str)
    else:
        Rtr, Rva, Rte = reduced_1q(Str, nq), reduced_1q(Sva, nq), reduced_1q(Ste, nq)
        g = gamma or 1.0 / nq
        Ktr, Kva, Kte = projected_kernel(Rtr, Rtr, g), projected_kernel(Rva, Rtr, g), projected_kernel(Rte, Rtr, g)
    kt = time.time() - t0
    best, bestC = -1, Cs[0]
    for C in Cs:
        f = f1_score(yva, SVC(C=C, kernel="precomputed").fit(Ktr, ytr).predict(Kva), average="macro")
        if f > best:
            best, bestC = f, C
    t0 = time.time(); svm = SVC(C=bestC, kernel="precomputed", random_state=seed).fit(Ktr, ytr); ft = time.time() - t0
    proba = _scores_to_proba(svm.decision_function(Kte), len(np.unique(ytr)))
    pred = proba.argmax(1)
    name = name or f"QSVM-{fmap}" + ("" if kind == "fidelity" else "-proj")
    out = dict(model=name, family="quantum", pred=pred, proba=proba, train_time=kt + ft, infer_time=0.0,
               n_params=int(svm.dual_coef_.size), C=bestC, **metrics(yte, pred, proba, **mkw))
    if return_kernel:
        out["_Ktr"] = Ktr
    return out
