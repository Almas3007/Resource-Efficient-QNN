"""report: shared figure/table helpers (600-dpi PNG + vector PDF, Markdown + CSV tables)."""
import os
import numpy as np, pandas as pd
from qsec import plot_style, PALETTE, wilcoxon, mcnemar, bootstrap_diff

plt = plot_style()
from matplotlib.patches import FancyBboxPatch


def savefig(fig, path_noext):
    os.makedirs(os.path.dirname(path_noext), exist_ok=True)
    fig.savefig(path_noext + ".png")
    fig.savefig(path_noext + ".pdf")
    plt.close(fig)


def color_for(model):
    m = model.lower()
    if "qsvm" in m or "vqc" in m or "quantum" in m:
        return PALETTE["quantum2"] if ("proj" in m or "l=1" in m) else PALETTE["quantum"]
    if "forest" in m or "xgb" in m:
        return PALETTE["tree"]
    if "threshold" in m or "qber" in m:
        return PALETTE["grey"]
    return PALETTE["classical"]


def agg(df, by, metrics_=("acc", "bal_acc", "f1", "mcc", "auc")):
    cols = [c for c in metrics_ if c in df.columns]
    g = df.groupby(by)
    mean, std = g[cols].mean(), g[cols].std()
    out = mean.copy().astype(object)
    for c in cols:
        out[c] = [f"{m:.4f} ± {s:.4f}" if not np.isnan(s) else f"{m:.4f}" for m, s in zip(mean[c], std[c])]
    extra = [c for c in ("train_time", "n_params", "circuit_depth", "n_2q") if c in df.columns]
    for c in extra:
        out[c] = g[c].mean().round(2)
    out["n_seeds"] = g.size()
    return out.reset_index(), mean.reset_index()


def write_table(df, path_noext, title=None):
    os.makedirs(os.path.dirname(path_noext), exist_ok=True)
    df.to_csv(path_noext + ".csv", index=False)
    with open(path_noext + ".md", "w") as f:
        if title:
            f.write(f"**{title}**\n\n")
        f.write(df.to_markdown(index=False))
        f.write("\n")


def bar_compare(mean_df, std_df, model_col, metric, ax, order=None, label=None, xlim=None):
    d = mean_df.set_index(model_col)[metric]; s = std_df.set_index(model_col)[metric]
    order = order or list(d.sort_values().index)
    y = np.arange(len(order))
    ax.barh(y, d[order], xerr=s[order], color=[color_for(m) for m in order], height=0.66,
            error_kw=dict(lw=0.8, capsize=2))
    for yi, m in zip(y, order):
        ax.text(d[m] + (s[m] if not np.isnan(s[m]) else 0) + 0.003, yi, f"{d[m]:.3f}", va="center", fontsize=7)
    ax.set_yticks(y); ax.set_yticklabels(order)
    ax.set_xlabel(label or metric)
    if xlim:
        ax.set_xlim(*xlim)
    ax.grid(axis="y", visible=False)


def stats_table(df, model_col, metric, quantum, references, group_cols=()):
    """Wilcoxon signed-rank over seeds: each quantum model vs each reference (paired by seed)."""
    rows = []
    for q in quantum:
        for r in references:
            a = df[df[model_col] == q].sort_values("seed")[metric].to_numpy()
            b = df[df[model_col] == r].sort_values("seed")[metric].to_numpy()
            if len(a) == 0 or len(a) != len(b):
                continue
            rows.append(dict(quantum=q, reference=r, mean_diff=float(np.mean(a - b)),
                             wins=f"{int(np.sum(a > b))}/{len(a)}", wilcoxon_p=wilcoxon(a, b)))
    return pd.DataFrame(rows)


def paired_tests(y, preds, pairs):
    rows = []
    for a, b in pairs:
        if a not in preds or b not in preds:
            continue
        mc = mcnemar(y, preds[a], preds[b])
        lo, hi = bootstrap_diff(y, preds[a], preds[b])
        rows.append(dict(model_A=a, model_B=b, n01_A_only_correct=mc["n01"], n10_B_only_correct=mc["n10"],
                         mcnemar_p=mc["p"], dF1_95CI=f"[{lo:+.4f}, {hi:+.4f}]"))
    return pd.DataFrame(rows)


def pipeline_diagram(stages, path_noext, title=None, quantum_idx=(), width=11, height=2.3):
    """Left-to-right block diagram. stages: list of (heading, body) strings."""
    fig, ax = plt.subplots(figsize=(width, height))
    ax.set_xlim(0, len(stages) * 10); ax.set_ylim(0, 10); ax.axis("off")
    for i, (h, b) in enumerate(stages):
        x = i * 10 + 0.6
        q = i in quantum_idx
        fc = "#EEE9FA" if q else "#E6F2F1"
        ec = PALETTE["quantum"] if q else PALETTE["classical"]
        ax.add_patch(FancyBboxPatch((x, 1.2), 8.4, 7.6, boxstyle="round,pad=0.25,rounding_size=0.8",
                                    fc=fc, ec=ec, lw=1.2))
        ax.text(x + 4.2, 7.6, h, ha="center", va="center", fontsize=8.5, weight="bold", color=ec)
        ax.text(x + 4.2, 4.3, b, ha="center", va="center", fontsize=7, linespacing=1.35)
        if i < len(stages) - 1:
            ax.annotate("", xy=(x + 9.7, 5), xytext=(x + 8.9, 5),
                        arrowprops=dict(arrowstyle="-|>", color="#444", lw=1.1))
    if title:
        ax.set_title(title, fontsize=9.5, loc="left")
    savefig(fig, path_noext)


def draw_circuit(qnode_fn, args, path_noext, decimals=None):
    import pennylane as qml
    fig, ax = qml.draw_mpl(qnode_fn, decimals=decimals, style="pennylane", level="device")(*args)
    fig.set_dpi(150)
    savefig(fig, path_noext)


def confusion(ax, y, p, labels, title):
    from sklearn.metrics import confusion_matrix
    cm = confusion_matrix(y, p, labels=range(len(labels)), normalize="true")
    ax.imshow(cm, cmap="Purples" if ("VQC" in title or "QSVM" in title) else "Greens", vmin=0, vmax=1)
    for i in range(len(labels)):
        for j in range(len(labels)):
            ax.text(j, i, f"{cm[i, j]:.2f}", ha="center", va="center", fontsize=7,
                    color="white" if cm[i, j] > 0.6 else "black")
    ax.set_xticks(range(len(labels))); ax.set_xticklabels(labels, rotation=35, ha="right")
    ax.set_yticks(range(len(labels))); ax.set_yticklabels(labels)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title(title, fontsize=8.5); ax.grid(False)
