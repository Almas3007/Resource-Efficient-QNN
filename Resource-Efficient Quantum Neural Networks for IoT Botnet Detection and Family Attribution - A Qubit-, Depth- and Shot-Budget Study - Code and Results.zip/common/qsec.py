"""qsec: shared hybrid quantum-classical toolkit for the five Quantum-Intelligence chapters.

Everything runs on exact simulators (PennyLane default.qubit / default.mixed) so results are reproducible.
Contents
  data      : stratified subsampling, PCA -> [0, pi] reduction to n qubits
  VQC       : angle-embedded variational classifier (optionally data re-uploading) + linear read-out
  kernels   : fidelity (state-overlap) and projected quantum kernels, ideal or depolarising-noise,
              finite-shot estimation, purity-based mitigation, PSD repair
  metrics   : accuracy, balanced accuracy, macro-F1, MCC, ROC-AUC, FPR/FNR, cost
  stats     : mean +- sd, Wilcoxon signed-rank, paired bootstrap CI, McNemar
"""
import os, time, json, math, random
import numpy as np
import xgboost  # noqa: F401  (must be imported before torch on macOS: libomp clash -> segfault)
import torch, torch.nn as nn, torch.nn.functional as F
import pennylane as qml
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, f1_score, matthews_corrcoef,
                             roc_auc_score, confusion_matrix)
from scipy import stats as sps

torch.set_num_threads(int(os.environ.get("QSEC_THREADS", 1)))  # >1 thread + xgboost libomp -> segfault on macOS
torch.set_default_dtype(torch.float64)
PI = math.pi


# ----------------------------------------------------------------------------- utilities
def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)


def stratified_sample(y, n, seed, idx=None):
    """Return indices of a class-balanced-as-possible sample of size n (equal per class, capped by availability)."""
    rng = np.random.default_rng(seed)
    idx = np.arange(len(y)) if idx is None else np.asarray(idx)
    classes = np.unique(y[idx])
    per = n // len(classes)
    out = []
    for c in classes:
        pool = idx[y[idx] == c]
        out.append(rng.choice(pool, size=min(per, len(pool)), replace=False))
    out = np.concatenate(out)
    rng.shuffle(out)
    return out


class Reducer:
    """Standardise -> PCA(n) -> robust (1-99 pct) min-max to [0, pi] (fitted on training data only; test values clipped)."""

    def __init__(self, n, method="pca", feat_idx=None):
        self.n, self.method, self.feat_idx = n, method, feat_idx

    def fit(self, X):
        self.sc = StandardScaler().fit(X)
        Z = self.sc.transform(X)
        if self.method == "pca":
            self.pca = PCA(self.n, random_state=0).fit(Z)
            Z = self.pca.transform(Z)
        else:  # pre-selected feature subset
            Z = Z[:, self.feat_idx]
        # robust range (1st-99th percentile) so heavy-tailed security features do not squash the angles
        self.lo, self.hi = np.percentile(Z, 1, axis=0), np.percentile(Z, 99, axis=0)
        return self

    def transform(self, X):
        Z = self.sc.transform(X)
        Z = self.pca.transform(Z) if self.method == "pca" else Z[:, self.feat_idx]
        Z = (Z - self.lo) / np.where(self.hi - self.lo > 1e-12, self.hi - self.lo, 1.0)
        return np.clip(Z, 0, 1) * PI


# ----------------------------------------------------------------------------- variational classifier
class VQC(nn.Module):
    """RY angle embedding -> L x StronglyEntanglingLayers (optionally re-uploading the data before every layer)
    -> <Z_i> -> linear read-out to n_out logits.  Optional depolarising noise p after every layer (default.mixed)."""

    def __init__(self, nq, layers, n_out, reupload=False, noise=0.0, init_scale=PI, ansatz="strong"):
        super().__init__()
        self.nq, self.L, self.reupload, self.noise, self.ansatz = nq, layers, reupload, noise, ansatz
        shape = (layers, nq, 3) if ansatz == "strong" else (layers, nq)
        self.w = nn.Parameter(init_scale * (2 * torch.rand(*shape) - 1))
        self.head = nn.Linear(nq, n_out)
        dev = qml.device("default.mixed" if noise > 0 else "default.qubit", wires=nq)

        @qml.qnode(dev, interface="torch", diff_method="backprop")
        def circ(x, w):
            for l in range(self.L):
                if l == 0 or self.reupload:
                    qml.AngleEmbedding(x, wires=range(nq), rotation="Y")
                if self.ansatz == "strong":     # Rot(3 params) per qubit + CNOT ring
                    qml.StronglyEntanglingLayers(w[l:l + 1], wires=range(nq))
                else:                           # "basic": RY(1 param) per qubit + CNOT ring (hardware-light)
                    qml.BasicEntanglerLayers(w[l:l + 1], wires=range(nq), rotation=qml.RY)
                if self.noise > 0:
                    for q in range(nq):
                        qml.DepolarizingChannel(self.noise, wires=q)
            return [qml.expval(qml.PauliZ(i)) for i in range(nq)]

        self.circ = circ

    def quantum_features(self, x):
        return torch.stack(self.circ(x, self.w), dim=-1)

    def forward(self, x):
        return self.head(self.quantum_features(x))

    def forward_shots(self, x, shots, rng):
        """Finite-shot inference: each <Z_i> estimated from `shots` single-qubit measurements."""
        with torch.no_grad():
            e = self.quantum_features(torch.as_tensor(x)).numpy()
        if shots:
            p1 = np.clip((1 + e) / 2, 0, 1)
            e = 2 * rng.binomial(shots, p1) / shots - 1
        with torch.no_grad():
            return F.softmax(self.head(torch.tensor(e)), -1).numpy()

    def n_params(self):
        return sum(p.numel() for p in self.parameters())

    def resources(self):
        x = torch.zeros(self.nq)
        specs = qml.specs(self.circ, level="device")(x, self.w.detach())
        res = specs["resources"]
        return dict(depth=int(res.depth), gates=int(res.num_gates),
                    two_qubit=int(sum(v for k, v in res.gate_sizes.items() if k == 2)))


def train_torch(model, Xtr, ytr, Xva, yva, epochs=30, bs=64, lr=0.05, class_weight=None, seed=0,
                focal_gamma=0.0, verbose=False):
    """Mini-batch Adam; keeps the weights of the epoch with best validation macro-F1."""
    set_seed(seed)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    Xtr_t, ytr_t = torch.tensor(Xtr), torch.tensor(ytr, dtype=torch.long)
    Xva_t = torch.tensor(Xva)
    cw = None if class_weight is None else torch.tensor(class_weight)
    best, best_state, hist = -1, None, []
    t0 = time.time()
    for ep in range(epochs):
        model.train()
        perm = torch.randperm(len(Xtr_t))
        tot = 0.0
        for i in range(0, len(perm), bs):
            b = perm[i:i + bs]
            logits = model(Xtr_t[b])
            if focal_gamma > 0:
                logp = F.log_softmax(logits, -1)
                pt = logp.gather(1, ytr_t[b, None]).squeeze(1).exp()
                ce = F.nll_loss(logp, ytr_t[b], weight=cw, reduction="none")
                loss = ((1 - pt) ** focal_gamma * ce).mean()
            else:
                loss = F.cross_entropy(logits, ytr_t[b], weight=cw)
            opt.zero_grad(); loss.backward(); opt.step()
            tot += loss.item() * len(b)
        model.eval()
        with torch.no_grad():
            pv = model(Xva_t).argmax(-1).numpy()
        f1 = f1_score(yva, pv, average="macro")
        hist.append(dict(epoch=ep + 1, loss=tot / len(perm), val_f1=f1))
        if f1 > best:
            best, best_state = f1, {k: v.clone() for k, v in model.state_dict().items()}
        if verbose:
            print(f"  ep{ep + 1:02d} loss={tot / len(perm):.4f} valF1={f1:.4f}")
    model.load_state_dict(best_state)
    return dict(train_time=time.time() - t0, history=hist, best_val_f1=best)


def predict_proba_torch(model, X, bs=2048):
    model.eval()
    out = []
    with torch.no_grad():
        for i in range(0, len(X), bs):
            out.append(F.softmax(model(torch.tensor(X[i:i + bs])), -1).numpy())
    return np.concatenate(out)


# ----------------------------------------------------------------------------- quantum kernels
def _feature_map(x, nq, fmap, reps, bw):
    """x: (B, nq) broadcast tensor/array."""
    for _ in range(reps):
        if fmap == "angle":                      # product-state RY map (classically simple reference)
            qml.AngleEmbedding(bw * x, wires=range(nq), rotation="Y")
        elif fmap == "zz":                       # Havlicek et al. (2019) ZZ map, linear entanglement
            for q in range(nq):
                qml.Hadamard(wires=q)
                qml.RZ(2 * bw * x[..., q], wires=q)
            for q in range(nq - 1):
                qml.CNOT(wires=[q, q + 1])
                qml.RZ(2 * bw * (PI - x[..., q]) * (PI - x[..., q + 1]), wires=q + 1)
                qml.CNOT(wires=[q, q + 1])
        elif fmap == "iqp_ry":                   # RY + ring of CRZ entanglers (hardware-efficient)
            qml.AngleEmbedding(bw * x, wires=range(nq), rotation="Y")
            for q in range(nq):
                qml.CRZ(bw * x[..., q] * x[..., (q + 1) % nq], wires=[q, (q + 1) % nq])
        else:
            raise ValueError(fmap)


def encode_states(X, nq, fmap="zz", reps=2, bw=1.0, noise=0.0, chunk=512):
    """Pure states (B, 2^nq) when noise == 0, otherwise density matrices (B, 2^nq, 2^nq) under local
    depolarising noise p applied to every qubit after each feature-map repetition."""
    mixed = noise > 0
    dev = qml.device("default.mixed" if mixed else "default.qubit", wires=nq)

    @qml.qnode(dev, interface="numpy")
    def circ(x):
        for r in range(reps):
            _feature_map(x, nq, fmap, 1, bw)
            if mixed:
                for q in range(nq):
                    qml.DepolarizingChannel(noise, wires=q)
        return qml.density_matrix(wires=range(nq)) if mixed else qml.state()

    outs = [np.asarray(circ(X[i:i + chunk])) for i in range(0, len(X), chunk)]
    return np.concatenate(outs)


def fidelity_kernel(A, B):
    """Ideal: |<a|b>|^2.  Mixed: Tr(rho_a rho_b) (swap-test kernel)."""
    if A.ndim == 2:
        return np.abs(A.conj() @ B.T) ** 2
    d = A.shape[-1]
    return np.real(A.reshape(len(A), -1).conj() @ B.reshape(len(B), -1).T)  # Tr(rho_a^dag rho_b)


def purity(S):
    if S.ndim == 2:
        return np.ones(len(S))
    return np.real(np.einsum("bij,bji->b", S, S))


def mitigate_depolarising(K, pa, pb, d):
    """Invert global-depolarising model rho = l|psi><psi| + (1-l) I/d per sample using purities:
       Tr(rho_a rho_b) = l_a l_b K + (1 - l_a l_b)/d ;  Tr(rho^2) = l^2 + (1-l^2)/d."""
    la = np.sqrt(np.clip((pa - 1 / d) / (1 - 1 / d), 1e-6, 1))
    lb = np.sqrt(np.clip((pb - 1 / d) / (1 - 1 / d), 1e-6, 1))
    L = np.outer(la, lb)
    return np.clip((K - (1 - L) / d) / L, 0, 1)


def reduced_1q(S, nq):
    """Single-qubit reduced density matrices (B, nq, 2, 2) from states or density matrices."""
    B = len(S)
    if S.ndim == 2:  # pure states: contract directly, never form the 2^n x 2^n density matrix
        T = S.reshape([B] + [2] * nq)
        out = np.empty((B, nq, 2, 2), dtype=complex)
        for q in range(nq):
            Tq = np.moveaxis(T, q + 1, 1).reshape(B, 2, -1)
            out[:, q] = Tq @ Tq.conj().transpose(0, 2, 1)
        return out
    T = S.reshape([B] + [2] * (2 * nq))
    out = np.empty((B, nq, 2, 2), dtype=complex)
    letters = "abcdefghijklmnopqrstuvwxyz"
    for q in range(nq):
        ins = list(letters[:nq]); outs = list(letters[nq:2 * nq])
        for k in range(nq):
            if k != q:
                outs[k] = ins[k]
        expr = "Z" + "".join(ins) + "".join(outs) + "->Z" + ins[q] + outs[q]
        out[:, q] = np.einsum(expr, T)
    return out


def projected_kernel(RA, RB, gamma):
    """Huang et al. (2021) projected quantum kernel on 1-qubit RDMs."""
    fa = RA.reshape(len(RA), -1); fb = RB.reshape(len(RB), -1)
    d2 = (np.abs(fa) ** 2).sum(1)[:, None] + (np.abs(fb) ** 2).sum(1)[None] - 2 * np.real(fa.conj() @ fb.T)
    return np.exp(-gamma * np.clip(d2, 0, None))


def shot_noise(K, shots, rng):
    """Finite-shot estimate of a probability-valued kernel (compute-uncompute / swap-test, Bernoulli)."""
    if shots is None or shots <= 0:
        return K
    return rng.binomial(shots, np.clip(K, 0, 1)) / shots


def psd_repair(K):
    """Project a (noisy) symmetric training Gram matrix onto the PSD cone (eigenvalue clipping)."""
    K = 0.5 * (K + K.T)
    w, V = np.linalg.eigh(K)
    return (V * np.clip(w, 0, None)) @ V.T


def kernel_concentration(K):
    """Off-diagonal mean/variance: exponential concentration diagnostic (Thanasilp et al. 2022)."""
    m = ~np.eye(len(K), dtype=bool) if K.shape[0] == K.shape[1] else np.ones_like(K, bool)
    return float(K[m].mean()), float(K[m].var())


def kernel_target_alignment(K, y):
    yy = np.where(y[:, None] == y[None], 1.0, -1.0)
    return float((K * yy).sum() / (np.linalg.norm(K) * np.linalg.norm(yy)))


# ----------------------------------------------------------------------------- metrics and statistics
def metrics(y, pred, proba=None, cost_fn=1.0, cost_fp=1.0):
    m = dict(acc=accuracy_score(y, pred), bal_acc=balanced_accuracy_score(y, pred),
             f1=f1_score(y, pred, average="macro"), mcc=matthews_corrcoef(y, pred))
    classes = np.unique(y)
    if proba is not None:
        try:
            m["auc"] = (roc_auc_score(y, proba[:, 1]) if proba.shape[1] == 2
                        else roc_auc_score(y, proba, multi_class="ovr", average="macro"))
        except ValueError:
            m["auc"] = float("nan")
    if len(classes) == 2:
        tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
        m["fpr"] = fp / max(fp + tn, 1); m["fnr"] = fn / max(fn + tp, 1)
        m["cost"] = (cost_fn * fn + cost_fp * fp) / len(y)
    return {k: float(v) for k, v in m.items()}


def summarize(df, by, cols):
    g = df.groupby(by)[cols]
    out = g.mean().round(4).astype(str) + " ± " + g.std().round(4).astype(str)
    return out.reset_index()


def wilcoxon(a, b):
    a, b = np.asarray(a), np.asarray(b)
    if np.allclose(a, b):
        return 1.0
    try:
        return float(sps.wilcoxon(a, b, zero_method="zsplit").pvalue)
    except ValueError:
        return float("nan")


def mcnemar(y, pa, pb):
    """Exact (binomial) McNemar test on paired predictions."""
    a_ok, b_ok = pa == y, pb == y
    n01 = int(np.sum(a_ok & ~b_ok)); n10 = int(np.sum(~a_ok & b_ok))
    n = n01 + n10
    p = 1.0 if n == 0 else float(sps.binomtest(min(n01, n10), n, 0.5).pvalue)
    return dict(n01=n01, n10=n10, p=p)


def bootstrap_diff(y, pa, pb, fn=None, B=2000, seed=0):
    fn = fn or (lambda yt, p: f1_score(yt, p, average="macro"))
    rng = np.random.default_rng(seed)
    n = len(y); d = []
    for _ in range(B):
        i = rng.integers(0, n, n)
        d.append(fn(y[i], pa[i]) - fn(y[i], pb[i]))
    return float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))


def save_json(obj, path):
    with open(path, "w") as f:
        json.dump(obj, f, indent=1, default=float)


# ----------------------------------------------------------------------------- plotting style
def plot_style():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"figure.dpi": 150, "savefig.dpi": 600, "font.size": 9, "font.family": "DejaVu Sans",
                         "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                         "grid.alpha": 0.25, "legend.frameon": False, "savefig.bbox": "tight"})
    return plt


PALETTE = {"quantum": "#5B3FA8", "quantum2": "#9C7CE0", "classical": "#2C7A7B", "classical2": "#7FB8B0",
           "tree": "#C05621", "grey": "#6B7280", "red": "#B83232"}
