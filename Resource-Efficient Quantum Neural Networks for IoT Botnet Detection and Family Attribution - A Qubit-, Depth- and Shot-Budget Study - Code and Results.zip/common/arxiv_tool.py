"""Small arXiv helper: search, fetch metadata by id, download PDFs (polite 3 s delay)."""
import re, sys, time, json, os, urllib.parse, urllib.request

API = "https://export.arxiv.org/api/query?"
UA = {"User-Agent": "research-chapter-reference-fetch/1.0"}


def _get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()


def _parse(xml):
    out = []
    for e in xml.split("<entry>")[1:]:
        aid = re.search(r"<id>https?://arxiv.org/abs/([^<]+)</id>", e).group(1)
        title = " ".join(re.search(r"<title>(.*?)</title>", e, re.S).group(1).split())
        year = re.search(r"<published>(\d{4})", e).group(1)
        authors = [" ".join(a.split()) for a in re.findall(r"<name>(.*?)</name>", e, re.S)]
        jref = re.search(r"<arxiv:journal_ref[^>]*>(.*?)</arxiv:journal_ref>", e, re.S)
        doi = re.search(r"<arxiv:doi[^>]*>(.*?)</arxiv:doi>", e, re.S)
        out.append(dict(id=re.sub(r"v\d+$", "", aid), title=title, year=year, authors=authors,
                        journal_ref=" ".join(jref.group(1).split()) if jref else "",
                        doi=doi.group(1).strip() if doi else ""))
    return out


def search(q, n=10):
    return _parse(_get(API + urllib.parse.urlencode(dict(search_query=q, max_results=n, sortBy="relevance"))).decode())


def meta(ids):
    return _parse(_get(API + urllib.parse.urlencode(dict(id_list=",".join(ids), max_results=len(ids)))).decode())


def download(ids, outdir):
    os.makedirs(outdir, exist_ok=True)
    recs = meta(ids)
    for r in recs:
        first = r["authors"][0].split()[-1] if r["authors"] else "anon"
        short = re.sub(r"[^A-Za-z0-9]+", "_", r["title"])[:60].strip("_")
        fn = f"{outdir}/{first}{r['year']}_{short}.pdf"
        if not os.path.exists(fn):
            time.sleep(3)
            data = _get(f"https://arxiv.org/pdf/{r['id']}")
            assert data[:4] == b"%PDF", f"not a PDF: {r['id']}"
            open(fn, "wb").write(data)
        r["file"] = os.path.basename(fn)
        print(f"{r['id']:<20} {r['year']} {first:<14} {r['title'][:80]}")
    json.dump(recs, open(f"{outdir}/references.json", "w"), indent=1)
    return recs


if __name__ == "__main__":
    for q in sys.argv[1:]:
        print("==", q)
        for r in search(q, 8):
            print(f"  {r['id']:<18} {r['year']} {r['title'][:100]}")
        time.sleep(3)
