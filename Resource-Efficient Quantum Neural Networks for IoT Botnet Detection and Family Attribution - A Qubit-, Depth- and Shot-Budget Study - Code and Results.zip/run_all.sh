#!/usr/bin/env bash
# Reproduce every experiment, figure and table (CPU, ~45 min on an 8-core laptop).
# Data must already be in each QI-0x/data folder (see README.md -> "Data sources").
set -euo pipefail
cd "$(dirname "$0")"
export QSEC_THREADS=1   # torch single-threaded: avoids an xgboost/torch libomp clash on macOS

python3 QI-04_IoT_Botnet_ResourceQNN/src/prepare_data.py          # builds nbaiot_sample.parquet from n_baiot.zip
for d in QI-01_Malware_HybridQML QI-02_IDS_ExplainableVQC QI-03_NoiseAware_QuantumKernel \
         QI-04_IoT_Botnet_ResourceQNN QI-05_BB84_QKD_EavesdropDetection; do
  echo "=== $d"
  python3 "$d/src/run_experiments.py" --seeds 5 --workers 5 > "$d/results/run_log.txt" 2>&1
  if [ "$d" = QI-03_NoiseAware_QuantumKernel ]; then python3 "$d/src/classical_baselines.py"; fi
  python3 "$d/src/make_figures.py"
done
